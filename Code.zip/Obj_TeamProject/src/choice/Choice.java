package choice;

import list.LinkedList;
import app.AppView;
import list.Iterator;

public class Choice implements BasicChoice {
	private String ChosenSubject;// 선택받은 과목명 or 교수님
	private String[] PrioritySet;// 우선순위 형태로 과목들이 저장될 배열
	private int NumberOfSubjects;// 입력받을 총 배열 개수
	private LinkedList<String> aList;
	private LinkedList<String>[] FinalList;

	public Choice(int theNumberOfSubjects) {
		this.setNumberOfSubjects(theNumberOfSubjects);
		this.setPrioritySet(new String[theNumberOfSubjects]);
		this.setLinkedList(new LinkedList<String>());
		this.setFinalList(new LinkedList[theNumberOfSubjects]);
	}

	int[] a = new int[5];

	private void setPrioritySet(String[] aString) {
		this.PrioritySet = aString;
	}

	public String[] getPrioritySet() {
		return this.PrioritySet;
	}

	public String getChosenSubject() {
		return this.ChosenSubject;
	}

	private void setChosenSubject(String newChoose) {
		this.ChosenSubject = newChoose;

	}

	private void setNumberOfSubjects(int newInt) {
		this.NumberOfSubjects = newInt;
	}

	public int getNumberOfSubjects() {
		return this.NumberOfSubjects;
	}

	private String PrioritySet(int i) {
		return this.PrioritySet[i];
	}

	private void setLinkedList(LinkedList<String> aList) {
		this.aList = aList;
	}

	public LinkedList<String> getLinkedList() {
		return this.aList;
	}

	public LinkedList<String>[] getFinalList() {
		return this.FinalList;
	}

	private void setFinalList(LinkedList<String>[] newList) {
		this.FinalList = newList;
	}

	private void setPrioritySetValue(int i, String aString) {
		this.PrioritySet[i] = aString;
	}

	private void ChoosethePriority(String ClassName) {
		for (int i = 0; i < this.getNumberOfSubjects(); i++) {
			if (this.PrioritySet(i) == null) {
				this.setPrioritySetValue(i, ClassName);
				return;
			}
		}
	}

	private void ChoosethePriority_2(String ProfessorName) {
		this.getLinkedList().add(ProfessorName);
	}

	public void SettingFinalList(int input) {
		LinkedList<String>[] temp = this.getFinalList();
		temp[input] = this.getLinkedList();
		this.setFinalList(temp);
		this.setLinkedList(new LinkedList<String>());
	}

	@Override
	public void MakingChoice(String ClassName) {
		// TODO Auto-generated method stub
		this.setChosenSubject(ClassName);
		this.ChoosethePriority(getChosenSubject());
	}

	@Override
	public void MakingChoice_2(String ProfessorName) {
		// TODO Auto-generated method stub
		this.setChosenSubject(ProfessorName);
		this.ChoosethePriority_2(getChosenSubject());
	}

	@Override
	public String[] FinalPriorityValue() {
		// TODO Auto-generated method stub
		return this.getPrioritySet();
	}

	@Override
	public LinkedList<String> FinalPriorityValue_2() {
		return this.getLinkedList();
	}

}