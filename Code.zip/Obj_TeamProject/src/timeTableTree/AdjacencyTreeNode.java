package timeTableTree;

public class AdjacencyTreeNode extends TreeNode {
	private AdjacencyTreeNode _period;

	public void setPeriod(AdjacencyTreeNode newPeriod) {
		this._period = newPeriod;
	}

	public AdjacencyTreeNode period() {
		return _period;
	}

	public AdjacencyTreeNode(TreeNode givenTreeNode) {
		super(givenTreeNode.oneLectureData());
		this.setPeriod(null);
	}	
}