package choice;

import list.LinkedList;

public interface BasicChoice {

	public void MakingChoice(String input);

	public void MakingChoice_2(String input);

	public String[] FinalPriorityValue();

	public LinkedList<String> FinalPriorityValue_2();
}