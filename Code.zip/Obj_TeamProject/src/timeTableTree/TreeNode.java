package timeTableTree;

public class TreeNode {

	private String _oneLectureData;
	private String _subject;
	private int _dividedClass;
	private String _professor;
	private double[][] _time;
	private TreeNode[] _next;
	private int _level;

	protected int level() {
		return this._level;
	}

	protected void setLevel(int newLevel) {
		this._level = newLevel;
	}

	public String oneLectureData() {
		return this._oneLectureData;
	}

	private void setOneLectureData(String newOneLectureData) {
		this._oneLectureData = newOneLectureData;
	}

	public void setNext(TreeNode[] newNext) {
		this._next = newNext;
	}

	public TreeNode[] next() {
		return _next;
	}

	private void setSubject(String newSub) {
		this._subject = newSub;
	}

	public String subject() {
		return this._subject;
	}

	private void setDividedClass(int div) {
		this._dividedClass = div;
	}

	public int dividedClass() {
		return this._dividedClass;
	}

	private void setProfessor(String name) {
		this._professor = name;
	}

	public String professor() {
		return this._professor;
	}

	private void setTime(double[][] newTime) {
		this._time = newTime;
	}

	public double[][] time() {
		return this._time;
	}

	public TreeNode(String givenOneLectureData) {
		this.setOneLectureData(givenOneLectureData);
		this.parsedLectureName();
		this.parsedProfessor();
//		this.parsedGrade();
		this.parsedLectureTime();
		this.parsedLectureNum();
	}

	private String[] splitData() {
		String givenData = this.oneLectureData();

		String[] returnData = givenData.split("\"");

		return returnData;
	}

	private void parsedLectureTime() {
		double[][] timeData = new double[2][3];
		String time = null;

		String[] parsedGivenData = this.splitData();

		for (int i = 0; i < parsedGivenData.length; i++) {
			if (parsedGivenData[i].equals("time")) {
				time = parsedGivenData[i + 2];
			}
		}

		time = TreeNode.unescapeJava(time);

		double[] daysOfWeek = this.parsedTimeTable(time);
		timeData[0][0] = daysOfWeek[0];
		timeData[1][0] = daysOfWeek[1];

		double[][] timesOfWeek = this.twoTimes(time);
		timeData[0][1] = timesOfWeek[0][0];
		timeData[0][2] = timesOfWeek[0][1];
		timeData[1][1] = timesOfWeek[1][0];
		timeData[1][2] = timesOfWeek[1][1];

		this.setTime(timeData);
	}

	private double[][] twoTimes(String timeData) {
		double[][] returnTimes = new double[2][2];

		if (timeData.length() == 0) {
			returnTimes[0][0] = -1;
			returnTimes[0][1] = -1;
			returnTimes[1][0] = -1;
			returnTimes[1][1] = -1;
		} else if (timeData.length() == 12) {
			char[] twoTimes = timeData.toCharArray();
			String first = new String(twoTimes, 1, 2);
			double firstTime = Double.parseDouble(first);
			if (twoTimes[3] == '3') {
				firstTime += 0.5;
			}
			String second = new String(twoTimes, 7, 2);
			double secondTime = Double.parseDouble(second);
			if (twoTimes[10] == '3') {
				secondTime += 0.5;
			}
			returnTimes[0][0] = firstTime;
			returnTimes[0][1] = secondTime;
			returnTimes[1][0] = -1;
			returnTimes[1][1] = -1;
		} else {
			char[] twoTimes = timeData.toCharArray();
			String first = new String(twoTimes, 1, 2);
			double firstTime = Double.parseDouble(first);
			if (twoTimes[3] == '3') {
				firstTime += 0.5;
			}
			String second = new String(twoTimes, 7, 2);
			double secondTime = Double.parseDouble(second);
			if (twoTimes[10] == '3') {
				secondTime += 0.5;
			}
			String third = new String(twoTimes, 15, 2);
			double thirdTime = Double.parseDouble(third);
			if (twoTimes[18] == '3') {
				firstTime += 0.5;
			}
			String fourth = new String(twoTimes, 21, 2);
			double fourthTime = Double.parseDouble(fourth);
			if (twoTimes[24] == '3') {
				secondTime += 0.5;
			}
			returnTimes[0][0] = firstTime;
			returnTimes[0][1] = secondTime;
			returnTimes[1][0] = thirdTime;
			returnTimes[1][1] = fourthTime;
		}

		return returnTimes;
	}

	/* \uc6d414:00~16:00, \ud65413:00~15:00 */

	private void parsedLectureNum() {
		int numData = 0;

		String[] parsedGivenData = this.splitData();

		for (int i = 0; i < parsedGivenData.length; i++) {
			if (parsedGivenData[i].equals("num")) {
				numData = Integer.parseInt(parsedGivenData[i + 2]);
			}
		}

		this.setDividedClass(numData);
	}

	private void parsedLectureName() {
		String nameData = null;

		String[] parsedGivenData = this.splitData();

		for (int i = 0; i < parsedGivenData.length; i++) {
			if (parsedGivenData[i].equals("name")) {
				nameData = parsedGivenData[i + 2];
			}
		}

		String removeSpace = TreeNode.unescapeJava(nameData);
		String returnData = "";
		String[] temp = removeSpace.split("\\s");

		for (int i = 0; i < temp.length; i++) {
			returnData += temp[i];
		}

		this.setSubject(returnData);
	}

	private void parsedProfessor() {
		String professorData = null;

		String[] parsedGivenData = this.splitData();

		for (int i = 0; i < parsedGivenData.length; i++) {
			if (parsedGivenData[i].equals("professor")) {
				professorData = parsedGivenData[i + 2];
			}
		}

		this.setProfessor(TreeNode.unescapeJava(professorData));
	}

//	private void parsedGrade() {
//		int gradeData = 0;
//		
//		String[] parsedGivenData = this.splitData();
//
//		for(int i = 0 ; i < parsedGivenData.length ; i++) {
//			if(parsedGivenData[i].equals("point")) {
//				gradeData = Integer.parseInt(parsedGivenData[i+2]);
//			}
//		}
//		
//		this.setGrades(gradeData);
//	}	

	private double[] parsedTimeTable(String timeData) {
		double[] returnData = new double[2];

		if (timeData.length() == 0) {
			returnData[0] = -1;
			returnData[1] = -1;
		} else if (timeData.length() == 12) {
			char[] day = timeData.toCharArray();
			returnData[0] = this.dayOfTheWeek(day[0]);
			returnData[1] = -1;
		} else {
			char[] day = timeData.toCharArray();
			returnData[0] = this.dayOfTheWeek(day[0]);
			returnData[1] = this.dayOfTheWeek(day[14]);
		}

		return returnData;
	}

	private int dayOfTheWeek(char input) {
		if (input == '월') {
			return 0;
		} else if (input == '화') {
			return 1;
		} else if (input == '수') {
			return 2;
		} else if (input == '목') {
			return 3;
		} else if (input == '금') {
			return 4;
		} else if (input == '토') {
			return 5;
		} else if (input == '일') {
			return 6;
		}
		return -1;
	}

	/*
	 * {"id":37765,"univ_id":1,"rating_id":null,"year":2018,
	 * "term":2,"major":"C00059","class":1,"type":"\uc804\uacf5(\uae30\ucd08)",
	 * "code":"27003","num":"10","name":"\ubbf8\ub798\uc124\uacc4\uc0c1\ub2f42",
	 * "point":"0","professor":"\uad8c\uc624\uc11d","mon":0,"tue":0,"wed":0,"thu":0,
	 * "fri":0,"sat":0,"room":null,"etc":"\uc808\ub300\ud3c9\uac00","time":"",
	 * "timetable_count":289}
	 */

	public static String unescapeJava(String escaped) {
		if (escaped.indexOf("\\u") == -1)
			return escaped;

		String processed = "";

		int position = escaped.indexOf("\\u");
		while (position != -1) {
			if (position != 0)
				processed += escaped.substring(0, position);
			String token = escaped.substring(position + 2, position + 6);
			escaped = escaped.substring(position + 6);
			processed += (char) Integer.parseInt(token, 16);
			position = escaped.indexOf("\\u");
		}
		processed += escaped;

		return processed;
	}

}