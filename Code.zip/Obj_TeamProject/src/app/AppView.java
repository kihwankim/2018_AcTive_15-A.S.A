package app;

import java.util.Scanner;

public final class AppView {
	private static Scanner scanner = new Scanner(System.in);

	private AppView() {
	}

	public static void outputLine(String aString) {
		System.out.println(aString);
	}

	public static void output(String aString) {
		System.out.print(aString);
	}

	public static String inputTheName(int i, int check) {
		if (i == 0 && check == 0) {
			AppView.scanner.nextLine();
		}
		AppView.output("[" + (i + 1) + " 순위] : ");
		String Name = AppView.scanner.nextLine();

		return Name;
	}

	public static int inputTheNumber() {
		int NumberOfSubjects;
		String scannedOne;
		while (true) {
			AppView.output("과목의 수를 입력하세요 : ");
			scannedOne = AppView.scanner.next();
			try {
				NumberOfSubjects = Integer.parseInt(scannedOne);
				return NumberOfSubjects;
			} catch (NumberFormatException e) {
				AppView.outputLine("(오류) 입력값에 오류가 있습니다 : " + scannedOne);
			}
		}
	}
}
