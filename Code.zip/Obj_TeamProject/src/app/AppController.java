package app;

import choice.Choice;
import list.LinkedList;
import timeTableTree.MakeTheNodeList;
import timeTableTree.AdjacencyTreeNode;
import timeTableTree.TimeTableTree;
import database.dataBaseList;

public class AppController {
	private dataBaseList _databaseList;
	private MakeTheNodeList<AdjacencyTreeNode> _makeTheNodeList;
	private Choice _choice;
	private TimeTableTree<AdjacencyTreeNode> _timeTableTree;
	private LinkedList<AdjacencyTreeNode[]> _forTreeList;

	
	private void setDataBaseList(dataBaseList newbase) {
		this._databaseList = newbase;
	}
	
	private dataBaseList dataBaseList() {
		return this._databaseList;
	}
	
	private void setMakeTheNodeList(MakeTheNodeList<AdjacencyTreeNode> newList) {
		this._makeTheNodeList = newList;
	}

	private MakeTheNodeList<AdjacencyTreeNode> makeTheNodeList() {
		return this._makeTheNodeList;
	}

	private void setChoice(Choice newChoice) {
		this._choice = newChoice;
	}

	private Choice choice() {
		return this._choice;
	}

	private void setTimeTableTree(TimeTableTree<AdjacencyTreeNode> newTimeTableTree) {
		this._timeTableTree = newTimeTableTree;
	}

	private TimeTableTree<AdjacencyTreeNode> timeTableTree() {
		return this._timeTableTree;
	}

	private void setLinkedList(LinkedList<AdjacencyTreeNode[]> newForTreeList) {
		this._forTreeList = newForTreeList;
	}

	private LinkedList<AdjacencyTreeNode[]> forTreeList() {
		return this._forTreeList;
	}

	private void setForTreeList(LinkedList<AdjacencyTreeNode[]> newTreeList) {
		this._forTreeList = newTreeList;
	}

	public AppController() {
		this.setChoice(null); // 생성자로 numerOfChoices랑 배열을 입력 해야한다.
		this.setMakeTheNodeList(null);
		this.setTimeTableTree(null);
		this.setDataBaseList(new dataBaseList("컴퓨터공학과"));
	}

	private void ChoosingPrioritySubject(int newNumberOfSubjects) {
		int theNumberOfSubjects = newNumberOfSubjects;// 값 입력 받아야 됨
		this.setChoice(new Choice(theNumberOfSubjects));
		AppView.outputLine("지금부터 우선순위 순으로 과목명을 입력합니다.");
		for (int i = 0; i < theNumberOfSubjects; i++) {
			String ClassesName = AppView.inputTheName(i, 0);
			this.choice().MakingChoice(ClassesName);
		}
	}

	private void ChoosingPriorityProfessor(int newNumberOfSubjects) {
		AppView.outputLine("지금부터 과목별로 교수님의 우선순위를 설정합니다.");
		String[] temp = this.choice().getPrioritySet();// 임시로 사용할 배열

		for (int j = 0; j < newNumberOfSubjects; j++) {
			{
				AppView.outputLine("현재 해당되는 과목 : " + temp[j]);// 현재 해당되는 과목명을 출력
				AppView.outputLine("해당하는 교수님을 모두 입력했다면 엔터를 입력하세요.");
				// 여기에 추가로 해당 과목에 포함되는 교수님들의 이름이 출력되면 좋겠는데 아직 방법을 모르겠음. 안되면 뭐 어쩔 수 없고.
				for (int i = 0; i >= 0; i++) {
					String ProfessorName = AppView.inputTheName(i, 1);
					if (ProfessorName.equals("")) {
						break;
					}
					this.choice().MakingChoice_2(ProfessorName);
				}
				this.choice().SettingFinalList(j);

			}
		}
	}

	public int InputTheNumberOfSubjects() {
		return AppView.inputTheNumber();
	}

	private void makeTheList() {
		this.setLinkedList(dataBaseList().dataBase());
		int theNumberOfSubject = this.InputTheNumberOfSubjects();
		this.ChoosingPrioritySubject(theNumberOfSubject);
		this.ChoosingPriorityProfessor(theNumberOfSubject);
		this.setMakeTheNodeList(
				new MakeTheNodeList(this.forTreeList(), choice().getPrioritySet(), choice().getNumberOfSubjects()));
		// forTreeList는 모든 과목이 저장되어있는 list, 2번째 인자는 모든 배열, 선택할 subjet의 개수
		this.setTimeTableTree(null);
		System.out.println(this.makeTheNodeList().makeTheList()); // 정렬된 list실패 여부 판별
		this.makeTheNodeList()
				.insertTheLevel(this.makeTheNodeList().treeListWithNext(this.makeTheNodeList().treeList()));
		// next생성, level이 저장된 list
		// 입력 할 linkedList<string>와 LikedList<E[]> 넣기

		this.makeTheNodeList().printAllWithNext(this.makeTheNodeList().treeList());
		this.makeTheNodeList().swapFromTheChoice(this.makeTheNodeList().treeList(), choice().getFinalList());
		AppView.outputLine("교수님 우선 순위대로 정렬을 한 후의 list");
		this.makeTheNodeList().printAllWithNext(this.makeTheNodeList().treeList());
		this.setTimeTableTree(new TimeTableTree(this.makeTheNodeList().treeList(), choice().getNumberOfSubjects()));
		this.timeTableTree().useAllOfRoot(this.makeTheNodeList().treeList().head().element(),
				this.makeTheNodeList().treeList());
		this.timeTableTree().printAllOfThem(this.timeTableTree().listOfpaths());
	}

	public void Run() {
		AppView.outputLine("만들어진 시간표는 다음과 같습니다. : ");
		this.makeTheList();

	}
}
