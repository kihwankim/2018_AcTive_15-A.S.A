package app;

import list.LinkedList;
import timeTableTree.AdjacencyTreeNode;
import timeTableTree.MakeTheNodeList;

public class _main {

	public static void main(String[] args) {
		/*temp t1 = new temp();
		t1.testList();	//리스트
		MakeTheNodeList m1 = new MakeTheNodeList();
		LinkedList<AdjacencyTreeNode[]> listthing = t1.testList();
		m1.swapFromTheChoice(listthing, t1.tempString());
		m1.printAllWithNext(listthing);
		*/
		AppController appController = new AppController();
		appController.Run();
	}
}